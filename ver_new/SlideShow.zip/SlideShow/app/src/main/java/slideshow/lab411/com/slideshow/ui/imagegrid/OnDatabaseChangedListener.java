package slideshow.lab411.com.slideshow.ui.imagegrid;

/**
 * Created by ld on 07/12/2017.
 */

public interface OnDatabaseChangedListener {
    void onNewDatabaseEntryAdded();
    void onDatabaseEntryRenamed();
}
