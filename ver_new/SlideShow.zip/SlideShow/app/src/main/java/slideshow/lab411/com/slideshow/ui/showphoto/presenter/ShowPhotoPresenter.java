package slideshow.lab411.com.slideshow.ui.showphoto.presenter;

import slideshow.lab411.com.slideshow.base.BasePresenter;
import slideshow.lab411.com.slideshow.ui.showphoto.IShowPhotoContract;

public class ShowPhotoPresenter<V extends IShowPhotoContract.IShowPhotoView> extends BasePresenter<V>
        implements IShowPhotoContract.IShowPhotoPresenter<V> {

}
